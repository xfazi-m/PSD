import { useState, useRef } from 'react';
import { DropZone } from './components/DropZone';
import { Gallery } from './components/Gallery';
import { Mascot } from './components/Mascot';
import { Toast } from './components/Toast';
import { PsdFile } from './types';
import { parsePsd } from './utils/psd';

export default function App() {
  const [files, setFiles] = useState<PsdFile[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const processFiles = async (fileList: FileList | File[] | null) => {
    if (!fileList || fileList.length === 0) return;

    setIsLoading(true);
    const psdFiles = Array.from(fileList).filter(file =>
      file.name.toLowerCase().endsWith('.psd') || file.type === 'image/vnd.adobe.photoshop'
    );

    if (psdFiles.length === 0) {
      showToast('⚠️ Wybierz pliki w formacie .psd');
      setIsLoading(false);
      return;
    }

    try {
      const parsedFiles = await Promise.all(psdFiles.map(file => parsePsd(file)));
      setFiles((prev) => [...parsedFiles, ...prev]);
      showToast(`✅ Pomyślnie wczytano pliki (${parsedFiles.length})`);
    } catch (err: any) {
      const errorMessage = err instanceof Error ? err.message : 'Wystąpił nieoczekiwany błąd';
      showToast(`❌ Błąd: ${errorMessage}`);
    } finally {
      setIsLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col font-sans text-slate-900 relative overflow-hidden">
      <Toast message={toastMessage} />
      
      {/* Hidden File Input for Native Mobile Picker & Header Button */}
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        multiple
        accept=".psd,image/vnd.adobe.photoshop"
        onChange={(e) => processFiles(e.target.files)}
      />

      {/* Header Navigation */}
      <header className="flex flex-col sm:flex-row items-center justify-between px-4 sm:px-10 py-5 sm:py-6 border-b border-slate-100 gap-5 sm:gap-0 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-electric rounded-lg flex items-center justify-center shrink-0">
            <span className="text-white font-bold text-xs">PSD</span>
          </div>
          <span className="text-xl font-semibold tracking-tight">PSD-Viewer</span>
        </div>
        <nav className="flex flex-wrap justify-center gap-4 sm:gap-8 text-sm font-medium text-slate-500">
          <button 
            onClick={() => showToast('Przeglądasz aktualnie wczytane pliki')} 
            className="text-electric font-semibold transition-colors"
          >
            Moje Pliki
          </button>
          <button 
            onClick={() => showToast('Historia plików wkrótce dostępna')} 
            className="hover:text-slate-900 transition-colors"
          >
            Historia
          </button>
          <button 
            onClick={() => showToast('Ustawienia panelu wkrótce dostępne')} 
            className="hover:text-slate-900 transition-colors"
          >
            Ustawienia
          </button>
        </nav>
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="w-full sm:w-auto px-6 py-3 sm:py-2 bg-electric text-white rounded-full text-sm font-medium hover:bg-electric-hover transition-colors shadow-sm active:scale-95 shrink-0 select-none"
        >
          Wgraj nowy plik
        </button>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col p-4 sm:p-10 overflow-auto">
        <DropZone 
          onFilesDropped={processFiles} 
          isLoading={isLoading} 
          onZoneClick={() => fileInputRef.current?.click()} 
        />
        <Gallery files={files} />
      </main>

      {/* Footer Info */}
      <footer className="px-4 sm:px-10 py-5 sm:py-4 text-[10px] sm:text-xs text-slate-400 flex flex-col sm:flex-row gap-3 sm:gap-0 justify-between items-center border-t border-slate-50 bg-slate-50/30 shrink-0">
        <div>Wersja 1.0.5 • System Gotowy</div>
        <div className="flex gap-4 sm:gap-6">
          <button onClick={() => showToast('Otwieram Politykę Prywatności...')} className="hover:text-slate-600 transition-colors">Prywatność</button>
          <button onClick={() => showToast('Regulamin Plików...')} className="hover:text-slate-600 transition-colors">Polityka Plików</button>
        </div>
      </footer>

      <Mascot />
    </div>
  );
}
