import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';

export function Mascot() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-4 right-4 sm:bottom-8 sm:right-8 z-50 flex flex-col sm:flex-row items-end sm:items-end gap-3 sm:gap-4 pointer-events-none origin-bottom-right scale-90 sm:scale-100">
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, x: 50, scale: 0.8 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 50, scale: 0.8 }}
            transition={{ type: 'spring', stiffness: 200, damping: 20 }}
            className="flex flex-col sm:flex-row items-end sm:items-end gap-2 sm:gap-4 pointer-events-auto"
          >
            {/* Speech Bubble */}
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: 0.3, type: 'spring' }}
              className="relative bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xl w-56 sm:w-64 sm:mb-12"
            >
              <button
                onClick={() => setIsVisible(false)}
                className="absolute top-2 right-2 text-slate-300 hover:text-slate-500 transition-colors p-1"
                title="Zamknij"
              >
                <X size={14} />
              </button>
              <p className="text-[11px] sm:text-xs leading-relaxed text-slate-700 pr-2">
                Cześć! Jestem <span className="text-electric font-bold">Psdeuś</span>. Przeciągnij tutaj lub kliknij obszar zrzutu, aby otworzyć pliki PSD!
              </p>
              <button
                onClick={() => setIsVisible(false)}
                className="mt-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest hover:text-electric transition-colors active:scale-95 origin-left"
              >
                Gotowe
              </button>
              {/* Bubble Tail */}
              <div className="absolute -bottom-2 right-8 w-4 h-4 bg-white border-b border-r border-slate-200 rotate-45 transform hidden sm:block" />
              <div className="absolute -right-2 bottom-6 w-4 h-4 bg-white border-r border-b border-slate-200 -rotate-45 transform block sm:hidden" />
            </motion.div>

            {/* Robot Mascot Character */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="relative w-24 h-24 drop-shadow-2xl cursor-pointer shrink-0"
              onClick={() => setIsVisible(false)}
              title="Zwiń maskotkę"
            >
              {/* Robot Body */}
              <div className="absolute inset-0 bg-gradient-to-b from-blue-50 to-blue-100 rounded-3xl border-2 border-electric flex items-center justify-center overflow-hidden">
                {/* Robot Face Screen */}
                <div className="w-16 h-12 bg-gray-900 rounded-xl relative overflow-hidden flex items-center justify-center gap-2">
                  {/* Eyes */}
                  <motion.div
                    animate={{ scaleY: [1, 0.1, 1, 1, 1] }}
                    transition={{ duration: 3, repeat: Infinity, times: [0, 0.05, 0.1, 0.95, 1], ease: "easeInOut" }}
                    className="w-3 h-4 rounded-full bg-electric"
                  />
                  <motion.div
                    animate={{ scaleY: [1, 0.1, 1, 1, 1] }}
                    transition={{ duration: 3, repeat: Infinity, times: [0, 0.05, 0.1, 0.95, 1], ease: "easeInOut", delay: 0.1 }}
                    className="w-3 h-4 rounded-full bg-electric"
                  />
                  {/* Scanning line */}
                  <motion.div
                     animate={{ y: [-24, 24] }}
                     transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                     className="absolute w-full h-0.5 bg-electric/30 blur-[1px]"
                  />
                </div>
              </div>
              {/* Antenna */}
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-1 h-4 bg-slate-300">
                <motion.div
                  animate={{ backgroundColor: ['#007AFF', '#60A5FA', '#007AFF'] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="absolute -top-2 -left-1 w-3 h-3 rounded-full"
                />
              </div>
              {/* Ears */}
              <div className="absolute top-1/2 -left-1 -translate-y-1/2 w-2 h-6 bg-slate-300 rounded-l-md" />
              <div className="absolute top-1/2 -right-1 -translate-y-1/2 w-2 h-6 bg-slate-300 rounded-r-md" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
