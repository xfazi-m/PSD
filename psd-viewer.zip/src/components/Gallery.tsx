import { motion, AnimatePresence } from 'motion/react';
import { PsdFile } from '../types';
import { formatBytes } from '../utils/psd';

interface GalleryProps {
  files: PsdFile[];
}

export function Gallery({ files }: GalleryProps) {
  if (files.length === 0) return null;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 flex-1 content-start w-full pb-32">
      <AnimatePresence>
        {files.map((file) => (
          <motion.div
            key={file.id}
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            whileHover={{ y: -5, scale: 1.02 }}
            className="group relative"
          >
            <div className="aspect-video bg-slate-100 rounded-xl overflow-hidden mb-3 border border-slate-200 group-hover:border-electric transition-all flex items-center justify-center shadow-sm relative">
              <img
                 src={file.previewUrl}
                 alt={file.name}
                 className="max-w-full max-h-full object-contain filter drop-shadow-md z-10 p-2"
              />
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 to-transparent z-0" />
            </div>
            <div className="flex justify-between items-start">
              <div className="overflow-hidden">
                <h3 className="text-sm font-bold truncate w-full pr-2 text-slate-900" title={file.name}>
                  {file.name}
                </h3>
                <p className="text-xs text-slate-400">
                  {file.width} x {file.height}
                </p>
              </div>
              <span className="text-[10px] font-mono bg-slate-100 px-2 py-1 rounded text-slate-500 shrink-0">
                {formatBytes(file.size)}
              </span>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
